//Reference list
//https://www.geeksforgeeks.org/arrays-in-java/
//https://www.w3schools.com/java/java_arrays.asp
//https://chatgpt.com/c/e40bcfac-d030-49f9-8388-73c49d0fc29d

package patient;
import java.util.ArrayList;
import java.util.Scanner;

// Base class for a Patient
class Patient {
    String name;
    int age;
    String gender;

    public Patient(String name, int age, String gender) {
        this.name = name;
        this.age = age;
        this.gender = gender;
    }

    //Code attribution
//- Author name: ChatGpt
//- Date​:6 July 2023
//- Title of program/source code​: Ai
//- Code version​: 4
//- Type: Java​
//- Web address or publisher: https://chatgpt.com/c/e40bcfac-d030-49f9-8388-73c49d0fc29d

    public String getName() {
        return name;
    }

    public boolean isEligible() {
        // This will be overridden in subclasses
        return false;
    }

    public String getHospital() {
        // This will be overridden in subclasses
        return "N/A";
    }
}

// Subclass for Female Patients
class FemalePatient extends Patient {

    public FemalePatient(String name, int age) {
        super(name, age, "Female");
    }

    @Override
    public boolean isEligible() {
        // Females below the age of 18 are not eligible
        return age >= 18;
    }

    @Override
    public String getHospital() {
        // Eligible females are treated at DBN Hospital
        return "Durban (DBN) Hospital";
    }
}

// Subclass for Male Patients
class MalePatient extends Patient {
    boolean hasChronicDisorder;

    public MalePatient(String name, int age, boolean hasChronicDisorder) {
        super(name, age, "Male");
        this.hasChronicDisorder = hasChronicDisorder;
    }

    @Override
    public boolean isEligible() {
        // Males above the age of 18 are eligible
        return age > 18;
    }

    @Override
    public String getHospital() {
        // If the patient has a chronic disorder, he is transferred to JHB Hospital
        if (hasChronicDisorder) {
            return "Johannesburg (JHB) Hospital";
        }
        // Otherwise, treated at DBN Hospital
        return "Durban (DBN) Hospital";
    }
}

public class HospitalAdmissionSystem {
    // Mock data storage
    static ArrayList<Patient> patients = new ArrayList<>();

    // Hardcoded login credentials
    static final String USERNAME = "Admin";
    static final String PASSWORD = "St@a77";

    // Method to simulate user login
    public static boolean login() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Username: ");
        String username = scanner.nextLine();
        System.out.print("Enter Password: ");
        String password = scanner.nextLine();

        return USERNAME.equals(username) && PASSWORD.equals(password);
    }

    // Method to check if patient record exists
    public static Patient searchPatientByName(String name) {
        for (Patient patient : patients) {
            if (patient.getName().equalsIgnoreCase(name)) {
                return patient;
            }
        }
        return null;
    }

    // Method to display patient eligibility and hospital
    public static void displayPatientEligibility() {
        for (Patient patient : patients) {
            System.out.println("Patient Name: " + patient.getName());
            if (patient.isEligible()) {
                System.out.println("Eligible for treatment at: " + patient.getHospital());
            } else {
                System.out.println("Not eligible for treatment at this facility.");
            }
            System.out.println();
        }
    }

    // Main method to run the program
    public static void main(String[] args) {
        // Adding some mock data
        patients.add(new FemalePatient("Alice", 25));
        patients.add(new FemalePatient("Jane", 16));
        patients.add(new MalePatient("Bob", 20, false));
        patients.add(new MalePatient("Tom", 30, true));
        patients.add(new MalePatient("Mike", 17, false));

        if (login()) {  // Attempt login
            System.out.println("Login successful!");

            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter patient name to search: ");
            String name = scanner.nextLine();

            Patient foundPatient = searchPatientByName(name);
            if (foundPatient != null) {
                System.out.println("Patient found: " + foundPatient.getName());
                System.out.println("Age: " + foundPatient.age + ", Gender: " + foundPatient.gender);
            } else {
                System.out.println("Patient record not found.");
            }

            //Code attribution
//- Author name: ChatGpt
//- Date​:6 July 2023
//- Title of program/source code​: Ai
//- Code version​: 4
//- Type: Java​
//- Web address or publisher: https://chatgpt.com/c/e40bcfac-d030-49f9-8388-73c49d0fc29d

            // Display eligibility for all patients
            System.out.println("\nPatient Eligibility and Hospital Assignment:");
            displayPatientEligibility();

        } else {
            System.out.println("Invalid credentials. Access denied.");
            
            //Code attribution
//- Author name: ChatGpt
//- Date​:6 July 2023
//- Title of program/source code​: Ai
//- Code version​: 4
//- Type: Java​
//- Web address or publisher: https://chatgpt.com/c/e40bcfac-d030-49f9-8388-73c49d0fc29d

        }
    }
}
